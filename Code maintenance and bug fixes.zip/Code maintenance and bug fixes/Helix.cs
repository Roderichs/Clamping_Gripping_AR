using UnityEngine;

public class Helix : MonoBehaviour
{
    [SerializeField]
    private float _size, _radius, _curve, _increment;
    [SerializeField]
    private float _rotSpeed;
    [SerializeField]
    private GameObject _cube;

    private void Start()
    {
        PlotHelix();
        if (_cube.name == "Blue_Cube")
        {
            transform.rotation = Quaternion.Euler(0, 0, 0);
        }
    }

    public void PlotHelix()
    {
        for (float i = 0; i < _size; i += _increment)
        {
            Instantiate
            (
                _cube,
                new Vector3
                (
                    transform.localPosition.x + (_radius * Mathf.Cos(i)),
                    transform.localPosition.y + (_curve * i),
                    transform.localPosition.z + (_radius * Mathf.Sin(i))
                ),
                Quaternion.Euler(0, i * 100, 0),
                this.transform
            );
        }
    }

    private void Update()
    {
        transform.Rotate(Vector3.up * _rotSpeed * Time.deltaTime);
    }    
}