/*
    > CONFIGURACION DE LA VELOCIDAD DE FOTOGRAMAS EN UNITY
        > El siguiente bloque de codigo consulta a Vuforia la velocidad de fotogramas
          y la establece mediante la API Application.targetFrameRate de Unity
*/
    private void OnVuforiaStarted()
    {
        int targetFps = VuforiaRenderer.Instance.GetRecommendedFps(VuforiaRenderer.FpsHint.NONE);

        if (Application.targetFrameRate != targetFps)
        {
            Debug.Log("Setting frame rate to " + targetFps + "fps");
            Application.targetFrameRate = targetFps;
        }
    }

/*
    > CONFIGURACION DEL MODO DE RENDIMIENTO Y LA VELOCIDAD D FOTOGRAMAS EN NATIVO
        > CONFIGURACION DEL MODO DE RENDIMINTO
            > Para cambiar el modo de dispositivos de camara en nativo. El cambio de
              modo debe hacerse |Vuforia::CameraDevice::getInstance().init()| antes y
              despues  |Vuforia::CameraDevice::getInstance().start()|
*/
    //Select the default camera mode:
    if (!Vuforia::CameraDevice::getInstance().selectVideoMode(
        Vuforia::CameraDevice::MODE_DEFAULT))
        return false;

    //Select the default camera mode:
    if (!Vuforia::CameraDevice::getInstance().selectVideoMode(
        Vuforia::CameraDevice::MODE_OPTIMIZE_SPEED))
        return false;

/*
    > CONFIGURACION DE LA VELOCIDAD DE FOTOGRAMAS
        > Establece el FPS recomendado en NINGUNO a menos que se ejecute en un dispositivo
          optico transparente
*/
    private boolean configureRenderingFrameRate()
    {
        int myRenderingOptions = Renderer.FPSHINT_FLAGS.FPSHINT_NONE;
        int vuforiaRecommendedFPS = Renderer.getInstance().GetRecommendedFps(myRenderingOptions);
        if
    }