using UnityEngine;
using System;

public class AOTProblemExample : MonoBehaviour, IReceiver
{
    public enum AnyEnum
    {
        Zero,
        One,
    }

    void Start()
    {
        /*
            Subtle trigger: The type of manager *must* be
            IManager, not Manager, to trigger the AOT problem.
        */
        IManager manager = new Manager();
        manager.SendMessage(this, AnyEnum.Zero);   
    }
    
    public void OnMessage<T>(T value)
    {
        Debug.LogFormat("Message value: {0}", value);
    }
}

public class Manager : IManager
{
    public void SendMessage<T>(IReceiver target, T value)
    {
        target.OnMessage(value);
    }
}

public interface IReceiver
{
    void OnMessage<T>(T value);
}

public interface IManager
{
    void SendMessage<T>(IReceiver target, T value);
}