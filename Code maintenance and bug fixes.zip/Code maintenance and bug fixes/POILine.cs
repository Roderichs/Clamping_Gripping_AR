using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class POILine : MonoBehaviour{
    /*_____Camera_____*/
    private GameObject camera;

    /*_____GameObject of interest to point the user towards_____*/
    public GameObject to;
    private LineRenderer line;
    public float lineWidthMultiplier = 0.5f;
    private float distance;
    public  float distanceMin = 50f;

    void Start()
    {
        camera = GameObject.FindGameObjectWithTag("Main Camera");
        line = this.gameObject.AddComponent<LineRenderer>();

        line.positionCount = 2;
        /*_____Thickness of the line_____*/
        line.widthMultiplier = lineWidthMultiplier;
    }

    /*_____Update is called once per frame_____*/
    void Update()
    {
        TrackableBehaviour.Status toStatus = to.transform.parent.GetComponent<TrackableBehaviour>().CurrentStatus;
        if (toStatus == TrackableBehaviour.Status.TRACKED || toStatus == TrackableBehaviour.Status.EXTENDED_TRACKED)
        {
            distance = Vector3.Distance(camera.transform.position, to.transform.position);
            if (distance > distanceMin)
            {
                line.enable = true;
                if (to != null)
                {
                    /*_____I think the error is here_____*/
                    line.SetPosition(0, camera.transform.position);
                    line.SetPosition(1, to.transform.position);
                }
            }
            else
            {
            line.enabled = false;   
        }
    }
}